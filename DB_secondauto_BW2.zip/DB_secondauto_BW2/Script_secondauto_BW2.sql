/* Scrivere il codice SQL (da scrivere su un documento testo dopo averlo testato) che restituisca le seguenti informazioni: */
-- 1.	Marca e Colore delle Auto di che costano più di 10.000 €
SELECT DISTINCT auto.marca AS Marca, auto.colore AS Colore, auto.prezzo AS Prezzo
FROM auto
WHERE auto.prezzo > 10000
ORDER BY 1, 2, 3;

-- 2.	Tutti i proprietari di un’auto di colore ROSSO 
SELECT proprietari.idproprietari AS id, proprietari.nominativo AS Proprietari
FROM proprietari JOIN sales ON proprietari.idproprietari = sales.idproprietari JOIN auto ON sales.targa = auto.targa
WHERE auto.colore LIKE 'Rosso'
GROUP BY id;

-- 3.	Costo totale di tutte le auto con Cilindrata superiore a 1600
SELECT SUM(auto.prezzo) AS CostoTotale
FROM auto
WHERE auto.cilindrata > 1600;

-- 4.	Targa e Nome del proprietario delle Auto in una concessionaria della Città di Roma 
SELECT auto.targa AS Targa, proprietari.nominativo AS Proprietario
FROM auto JOIN sales ON auto.targa = sales.targa JOIN proprietari ON sales.idproprietari = proprietari.idproprietari JOIN concessionaria ON concessionaria.idconcessionaria = sales.idconcessionaria
WHERE concessionaria.idconcessionaria =
	   (SELECT concessionaria.idconcessionaria
		FROM auto JOIN sales ON auto.targa = sales.targa JOIN proprietari ON sales.idproprietari = proprietari.idproprietari JOIN concessionaria ON concessionaria.idconcessionaria = sales.idconcessionaria
		WHERE concessionaria.citta LIKE 'Roma' 
		GROUP BY concessionaria.idconcessionaria
		HAVING SUM(auto.prezzo) =
			   (SELECT MAX(Roma2.PrezzoTotaleAuto)
				FROM
					   (SELECT concessionaria.idconcessionaria, SUM(auto.prezzo) AS PrezzoTotaleAuto
						FROM auto JOIN sales ON auto.targa = sales.targa JOIN proprietari ON sales.idproprietari = proprietari.idproprietari JOIN concessionaria ON concessionaria.idconcessionaria = sales.idconcessionaria
						WHERE concessionaria.citta LIKE 'Roma' 
						GROUP BY concessionaria.idconcessionaria
						HAVING COUNT(auto.targa) =
								(SELECT MAX(Roma.NumAuto) 
								 FROM
										(SELECT COUNT(auto.targa) AS NumAuto, concessionaria.idconcessionaria
										 FROM auto JOIN sales ON auto.targa = sales.targa JOIN proprietari ON sales.idproprietari = proprietari.idproprietari JOIN concessionaria ON concessionaria.idconcessionaria = sales.idconcessionaria
										 WHERE concessionaria.citta LIKE 'Roma'
										 GROUP BY concessionaria.idconcessionaria) 
										 AS Roma))
				AS Roma2)
		AND COUNT(auto.targa) = 
			   (SELECT MAX(Roma.NumAuto) 
			    FROM
					   (SELECT COUNT(auto.targa) AS NumAuto, concessionaria.idconcessionaria
					    FROM auto JOIN sales ON auto.targa = sales.targa JOIN proprietari ON sales.idproprietari = proprietari.idproprietari JOIN concessionaria ON concessionaria.idconcessionaria = sales.idconcessionaria
					    WHERE concessionaria.citta LIKE 'Roma'
					    GROUP BY concessionaria.idconcessionaria) 
					    AS Roma)
		LIMIT 1);

-- 5.	Per ogni Concessionaria, il numero di Auto 
SELECT concessionaria.idconcessionaria AS id, concessionaria.citta AS Citta, COUNT(auto.targa) AS NumAuto
FROM auto JOIN sales ON auto.targa = sales.targa JOIN concessionaria ON sales.idconcessionaria = concessionaria.idconcessionaria
GROUP BY concessionaria.idconcessionaria;

-- 6.	Il Responsabile di Concessionaria di tutte le auto con Cambio Automatico e Anno Acquisto 2010
SELECT concessionaria.responsabile AS Responsabile
FROM concessionaria JOIN Sales ON concessionaria.idconcessionaria = sales.idconcessionaria JOIN auto ON sales.targa = auto.targa
WHERE auto.tipocambio LIKE 'Automatico' AND YEAR(sales.dataacquisto) = 2010;

-- 7. Per ciascuna TARGA il colore, il prezzo e la città in cui si trova il veicolo (in base alla concessionaria, perchè dopo la vendita non possiamo stabilire dove va il veicolo)
SELECT auto.targa AS Targa, auto.colore AS Colore, auto.prezzo AS Prezzo, concessionaria.citta AS Citta
FROM concessionaria JOIN sales ON concessionaria.idconcessionaria = sales.idconcessionaria JOIN auto ON sales.targa = auto.targa;

-- 8. Le auto con almeno tre Proprietari 
SELECT conteggio.targa AS Targa
FROM
    (SELECT COUNT(proprietari.idproprietari) AS NumProprietari, auto.targa AS targa
     FROM auto JOIN sales ON auto.targa = sales.targa JOIN proprietari ON sales.idproprietari = proprietari.idproprietari
     GROUP BY auto.targa
     HAVING NumProprietari = 3) AS conteggio;

-- 9. La targa delle auto vendute nel 2015 (noi 2020 perchè per noi la vendita parte dal 2019)
SELECT auto.targa AS Targa
FROM auto JOIN sales ON auto.targa = sales.targa
WHERE YEAR(sales.datavendita) = 2020;

-- 10. La regione con più auto (trovare un modo per associare la Regione)
SELECT concessionaria.regione AS RegioneMaxAuto, COUNT(auto.targa) AS ConteggioAuto
FROM auto JOIN sales ON auto.targa = sales.targa JOIN concessionaria ON sales.idconcessionaria = concessionaria.idconcessionaria
GROUP BY Regione
HAVING conteggioAUTO = (SELECT MAX(conteggio.targa) FROM
							(SELECT COUNT(auto.targa) AS Targa, concessionaria.regione AS Regione
                             FROM auto JOIN sales ON auto.targa = sales.targa JOIN concessionaria ON sales.idconcessionaria = concessionaria.idconcessionaria
							 GROUP BY concessionaria.regione) AS conteggio
					   );

-- 11. La Targa delle auto che si trovano a Milano, con cambio automatico, colore rosso, di proprietari residenti a Milano
SELECT auto.targa AS Targa
FROM auto JOIN sales ON auto.targa = sales.targa JOIN proprietari ON sales.idproprietari = proprietari.idproprietari JOIN concessionaria ON sales.idconcessionaria = concessionaria.idconcessionaria
WHERE concessionaria.citta LIKE 'Milano'
	AND auto.tipocambio LIKE 'Automatico'
	AND auto.colore LIKE 'Rosso'
	AND proprietari.cittaresidenza LIKE 'Milano';
    
    
# ANALISI FATTURATO CONCESSIONARIE

CREATE VIEW FatturatoConcessionarie AS
    (SELECT 
        concessionaria.idconcessionaria,
        concessionaria.areageografica,
        concessionaria.regione,
        concessionaria.citta,
        YEAR(sales.datavendita) AS anno,
        QUARTER(sales.datavendita) AS trimestre,
        SUM(auto.prezzo) AS fatturato
    FROM
        auto
            JOIN
        sales ON auto.targa = sales.targa
            JOIN
        concessionaria ON sales.idconcessionaria = concessionaria.idconcessionaria
    GROUP BY concessionaria.idconcessionaria , concessionaria.areageografica , concessionaria.regione, 
    concessionaria.citta , anno , trimestre
    ORDER BY 2,3,4,1,5,6
    );
    
# GESTIONE CLIENTI PER CONCESSIONARIA
    
CREATE VIEW GestioneClienti AS
    (
    SELECT concessionaria.idconcessionaria, concessionaria.citta, concessionaria.regione, concessionaria.areageografica, COUNT(proprietari.idproprietari) AS NumClienti, 
    SUM(auto.prezzo) AS fatturato
    FROM
    auto JOIN sales ON auto.targa = sales.targa JOIN proprietari ON sales.idproprietari = proprietari.idproprietari 
    JOIN concessionaria ON concessionaria.idconcessionaria = sales.idconcessionaria
    GROUP BY concessionaria.idconcessionaria, concessionaria.citta, concessionaria.regione, concessionaria.areageografica
    ORDER BY 2,3
    );
